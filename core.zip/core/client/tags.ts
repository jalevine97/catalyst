export const TAGS = {
  cart: 'cart',
  checkout: 'checkout',
  customer: 'customer',
} as const;
