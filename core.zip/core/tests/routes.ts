export default {
  SHOP_ALL: '/shop-all',
  SAMPLE_ABLE_BREWING_SYSTEM: '/sample-able-brewing-system',
  ORBIT_TERRARIUM_LARGE: '/orbit-terrarium-large',
  BLOG: '/blog',
  BATH_LUXURY: '/bath/towels/luxury',
  CONTACT_US: '/contact-us',
  LOGIN: '/login',
  FOG_LINEN_CHAMBRAY: '/fog-linen-chambray-towel-beige-stripe/',
  PARFAIT_JAR: '/1-l-le-parfait-jar',
};
